from datetime import datetime
from http.client import responses
import json
from django.shortcuts import redirect, render
from django.http import HttpResponse, HttpResponseRedirect
from django.views import View
from yaml import serialize
from enduser import models
from django.contrib.auth.views import LoginView
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from.models import Customers
#Imports - login, logout, profile
from django.urls import reverse_lazy
from . import forms
from django.contrib.auth.decorators import login_required
from django.views.generic.edit import CreateView
#Only required for function if class not used
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User


#Temp
class CustomLoginView(LoginView):
    template_name = 'registration/login.html' 

# Create your views here.

#Home Page
def index(request):
    return render(request,'index.html')

#Products Page
def Products(request):
    queryset = models.Products.objects.all()
#added data
    data ={'products': models.Products.objects.all()}
    return render(request, 'product.html', {'products': queryset})


#Cart Page
def ShoppingCart(request):
    return render(request,'cart.html')


#About Us 
def about(request):
    return render(request,'about.html')


#Registration Page
def register_page(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

#New Login Page
def login_page(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password= request.POST.get('userpassword')
        user = authenticate(user_name=username, user_password=password)
        if user is not None:
            login(request, user)
            return redirect('index')
    return render(request, '/registration/login.html')



#terms Page
def terms(request):
    return render(request,'t&c.html')

#faq Page
def faq(request):
    return render(request,'faq.html')

#help Page
def help(request):
    return render(request,'help.html')

#contact
def contact(request):
    return render(request,'contact.html')

#checkout
def checkout(request):
    return render(request,'checkout.html')

#order
def order(request):
    if request.method == 'POST':
        return render(request,'order.html')

    else:
       return index(request)


#checkout
def ordercomplete(request):
    if(request.method=='POST'):
        shopping_list = request.POST.get('shopping_list')
        billingemail = request.POST.get('billing-email')
        name = request.POST.get('billing-name')
        addr = request.POST.get('billing-addr')
        zip = request.POST.get('billing-zip')
        city = request.POST.get('billing-city')
        country = request.POST.get('billing-country')
        cost = request.POST.get('shipping-cost')
        card = request.POST.get('card_number')
        expdate = request.POST.get('expiration_date')
        cvc = request.POST.get('cvc')
        
        cartitems = json.loads(shopping_list)

        cus = models.Customers.objects.filter(email=billingemail).first()
        cusno=0
        totalprice=0
        noitems=0
        newinvoice =None
        customer=None
        if (cus is None):
            newcustomer= models.Customers(name=name,lastname=name,cellno=0,email=billingemail)
            models.Customers.save(newcustomer)
            cusno = newcustomer.customerno
            customer = newcustomer
        else:
            cusno = cus.customerno
            customer = cus
        
        newinvoice = models.Invoices(invoicesamt=0,invoicesqty=0,invoicesdate=datetime.today(),invoicestype=0,invoicesfor=customer)
        
        models.Invoices.save(newinvoice)    
        

        newcart = models.Cart(cartqty=0,cartprice=0,invoice=newinvoice,cartstate=0,customerno=customer)

        models.Cart.save(newcart)

        for item in cartitems['items']:
            prod = models.Products.objects.get(idproducts=int(item['prodid']))
            newcartitem = models.Cartitems(cart=newcart,product=prod)
            totalprice +=item['price']
            noitems +=item['qty']
            models.Cartitems.save(newcartitem)

        newinvoice.invoicesamt=totalprice
        newinvoice.invoicesqty=noitems
        newinvoice.save()

        newcart.cartprice=totalprice
        newcart.cartqty=noitems
        newcart.save()

    return render(request,'completed.html',{'invoiceno': newinvoice.idinvoices})


    #to save the data
def register(self):
    self.save()


@staticmethod
def get_customer_by_email(email):
        try:
            return "Customer.objects.get"(email= email),
        except:
            return False,


def isExists(self):
        if "Customer.objects.filter"(email = self.email):
            return True

        return False,


#for profile page 
@login_required # limits the page for logged in user, otherwise redirect to login
def profile(request):
    userRec = models.AuthUser.objects.get(username=request.user)
    customer = models.Customers.objects.get(email=userRec.email)
    invoices = models.Invoices.objects.filter(invoicesfor=customer)
    carts = models.Cart.objects.filter(customerno=customer)
    cart_items = models.Cartitems.objects.filter(cart__in=carts)

    context = {
        'customer': customer,
        'invoices': invoices,
        'carts': carts,
        'cart_items': cart_items,
    }
    return render(request, 'profile.html', context)

#triggers the sign up page 
class SignUpView(CreateView):
    form_class = forms.CreateCustomerForm
    success_url = reverse_lazy('login')
    template_name = 'registration/register.html'

#Alternative, not utilised

def signup_view(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password1 == password2:
            if User.objects.filter(email=email).exists():
                return render(request, 'registration/register.html', {'error': 'Email is already in use.'})
            else:
                user = User.objects.create(
                    username=email,  # Use email as the username
                    first_name=first_name,
                    last_name=last_name,
                    email=email,
                    password=make_password(password1)
                )
                user.save()
                profile(request)
                return redirect('login')
        else:
            return render(request, 'registration/register.html', {'error': 'Passwords do not match.'})
    return render(request, 'registration/register.html')






# def home(request):
#     customer=1000
#     param1 = {
#         'name': models.Customers.objects.get(customerno=customer)
#     }
#     if len(param1)<=0:
#         return render(request,'login.html')
#     else:
#         return render(request,'index.html',param1)
    


# def dashboard(request):
#     username = "Monty Phahlane"
#     return render(request,'home.html',{'loggedinname':username})

# def landing(request):
#     loggedinuser = {
#         'user': models.Customers.objects.get(customerno=1000)
#     }
#     return render(request,'dashboard.html',loggedinuser)


# def customers(request):
#     customer_list = models.Customers.objects.all() 
#     return render(request, 'customers.html', {'customer_list': customer_list})

# def customer(request, customerno):
#     customer = models.Customers.objects.get(customerno=customerno) 
#     cus =models.Customers(name='Me',lastname='You',cellno=customerno,email='me@you.com')
#     models.Customers.save(cus)
#     return render(request, 'customer.html', {'customer': customer})





    
# class ProductsListView(generics.ListCreateAPIView):
#     queryset = models.Products.objects.all()
#     serializer_class = serializer.ProductsSerializer

# class ProductView(generics.ListCreateAPIView):

#     serializer_class = serializer.ProductsSerializer
#     def get_queryset(self):
#         # Access the 'param' URL parameter using self.kwargs
#         param = self.kwargs.get('param')

#         # Filter the queryset based on the 'param' value
#         queryset = models.Products.objects.get(idproducts=param)

#         return queryset

    
# class CartView(generics.ListCreateAPIView):
#     queryset = models.Cart.objects.all()
#     serializer_class = serializer.CartSerializer
