from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Customers

#Form to ensure that additional information is created in the customer table
class CreateCustomerForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    email = forms.EmailField(max_length=254, required=True)
    cellno = forms.CharField(max_length=45, required=True)

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control'})

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
            Customers.objects.create(
                user=user,
                name=self.cleaned_data['first_name'],
                lastname=self.cleaned_data['last_name'],
                email=self.cleaned_data['email'],
                cellno=self.cleaned_data['cellno']
            )
        return user
