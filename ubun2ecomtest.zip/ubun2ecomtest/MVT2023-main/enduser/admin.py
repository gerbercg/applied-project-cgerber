from django.contrib import admin
from .models import Customers, Invoices
from .models import Cart,Products,Productcategory,Cards,User
# Register your models here.


#Concrete Class
class CustomView(admin.ModelAdmin):
    list_display=['customerno','name','lastname']

class ProductsView(admin.ModelAdmin):
    list_display=['idproducts','productscode','productsname','productsdescription','productsprice','productscat','productsimg']

class ProductscatView(admin.ModelAdmin):
    list_display=['idproductcategory','productcategory','productcategorydescr']

class CartView(admin.ModelAdmin):
    list_display=['idcart','cartqty','cartprice','invoice','cartstate','customerno']

class CardsView(admin.ModelAdmin):
    list_display=['cardno','cardholder','expirydate','customerno','addressno']

class UsersView(admin.ModelAdmin):
    list_display=['user_id','user_name','email','user_password']


admin.site.register(Customers, CustomView)
admin.site.register(Cart,CartView)
admin.site.register(Products,ProductsView)
admin.site.register(Productcategory, ProductscatView)
admin.site.register(Cards,CardsView)

