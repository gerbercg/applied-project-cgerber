"""
URL configuration for backend project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path
from enduser import views
from django.contrib.auth import views as auth_views




urlpatterns = [
    path("admin/", admin.site.urls),
    path("",views.index),
    path("",views.index, name='home'),
    path("cart/",views.ShoppingCart),
    path('products/', views.Products),
    path('checkout/', views.checkout),
    path('order/', views.order,name='order'),    
    path('order/success/', views.ordercomplete,name='process_payment'),
    path("terms/", views.terms),
    path("about/", views.about),
    path("faq/", views.faq),
    path("help/", views.help),
    path("contact/", views.contact),
    path('register/', views.register_page, name='register'),
    path('registration/login/', views.login_page, name='login'),
    path('products/', views.Products, name='productslist'),

#Includes all URLS for built in pages and functionaity for user login, registration, password change, tc
    path('accounts/', include('django.contrib.auth.urls')),

#Use the built-in feature but with custom login page
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),    
 
#Signup page
    path('signup/', views.SignUpView.as_view(), name='signup'),
#Logout
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

#For Profile Page 
    path('accounts/profile/', views.profile, name='profile'),

    # path('customer/<int:customerno>/', views.customer, name='customer'),

]


   
    
    